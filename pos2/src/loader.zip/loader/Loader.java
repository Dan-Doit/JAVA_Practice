package loader;

import controller.FrontController;

public class Loader {
	

	public static void main(String[] args) {

		new FrontController();
//		String record = "7777,1234,훈짱,010-5680-8050,M";
//		//System.out.println(record.substring(0,4));
//		
//		String[] record2 = new String[2];
//		String re;
//		
//		re = "7777,1234,훈짱,010-5680-8050,M";
//		
//		re = re.substring(re.indexOf(",")+1);
//		re = re.substring(re.indexOf(",")+1);
//		re = re.substring(re.indexOf(",")+1);
//
//		System.out.println(re.substring(0,re.indexOf(",")));
		
		
		
//		for (int i = 0; i < record2.length; i++) {
//
//			//System.out.println(record2[i].substring(0,record2[i].indexOf(",")));
//			//substring 0부터 4의 -1까지 출력                                                   indexof , 까지 출력			
//			int beginIndex = record2[i].indexOf(",") + 9;
//			//beginindex는 , 앞부터 출력 7777다음부터 출력
//			String temp = record2[i].substring(beginIndex);
//			// temp는 7777다음부터 끝까지 출력
//			System.out.println(temp.substring(0,temp.indexOf(",")));
//			//0부터 7777다음부터 ,까지 출력 → 1234
//			
//			}

		
	}
	
}
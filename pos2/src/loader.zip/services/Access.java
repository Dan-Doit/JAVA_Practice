package services;

import data.DataAccessObject;
import data.UserInfoBean;

public class Access {

	public Access() {

	}

	public void entrance(UserInfoBean uib) {
		switch (uib.getRequestValue()) {
		case "A1":
			logIn(uib);
			break;
		case "A2":
			userReg(uib);
			break;
		case "A3":
			userMod(uib);
			break;
		}
		// uib.getRequestValue()에 저장되어 있는 
		// Request Value에 따라 logIn, userReg, userMod 메서드로 분기 
				
	}

	private void logIn(UserInfoBean uib) {
		DataAccessObject dao = new DataAccessObject();

		if (dao.isEmployee(0, uib)) {
			
			if (dao.isAccess(0, uib)) {
				dao.getUserInfo(0, uib);
				// 필요없는데이터 삭제
				uib.setRequestValue(null);
				uib.setAccessCode(null);
				
			}
		}

		// 로그인 성공 --> 
		// parameter로 전달받은 uib에 저장
		// 저장값  7777,훈짱,M, 20200924180000
		
		


		
	}

	private void userReg(UserInfoBean uib) {

	}

	private void userMod(UserInfoBean uib) {

	}

}

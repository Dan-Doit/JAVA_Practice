package data;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.text.AbstractDocument.BranchElement;

public class DataAccessObject {
	private String[] filePath = { 
			"D:\\dhspace\\pos2\\src\\data\\saler.txt",
			"D:\\dhspace\\pos2\\src\\data\\history.txt" , 
			"D:\\dhspace\\pos2\\src\\data\\salesInfo.txt", 
	"D:\\dhspace\\pos2\\src\\data\\goods.txt"};
	private File file;
	private FileReader fr;
	private BufferedReader br;
	private FileWriter fw;
	private BufferedWriter bw;

	public DataAccessObject(){}

	// 직원코드 여부 확인
	public boolean isEmployee(int fileIndex, UserInfoBean uib) {
		boolean result = false;
		file = new File(filePath[fileIndex]);
		try {
			fr = new FileReader(file);
			br = new BufferedReader(fr);
			String record = null;
			while ((record = br.readLine()) !=null) { // 괄호에 있는거 먼저 실행하고 트루인지 판단함.

				if (uib.getEmployeeCode().equals(record.substring(0,4))) {
					result = true;
					break;

				}

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;
	}
	// 패스워드 여부 확인
	public boolean isAccess(int fileIndex, UserInfoBean uib) {
		boolean result = false;
		file = new File(filePath[fileIndex]);
		try {
			fr = new FileReader(file);
			br = new BufferedReader(fr);
			String record;
			while ((record = br.readLine()) !=null) {
				if (uib.getEmployeeCode().equals(record.substring(0,4))) {
					String pass = record.substring(5);
					if (uib.getAccessCode().equals(pass.substring(0,pass.indexOf(",")))) {
						result = true;
						break;
					}

				}

			}






		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;
	}
	// 특정 직원정보 가져오기
	public void getUserInfo(int fileIndex, UserInfoBean uib) {
		file = new File(filePath[fileIndex]);
		try {
			fr = new FileReader(file);
			br = new BufferedReader(fr);
			String record;
			while ((record=br.readLine()) != null) {
				if (uib.getEmployeeCode().equals(record.substring(0,4))) {
					String pass = record.substring(5);
					if (uib.getAccessCode().equals(pass.substring(0,pass.indexOf(",")))) {
						     			//7777,1234,강동훈,010-5680-8050,M
								pass = pass.substring(pass.indexOf(",")+1);
								
								uib.setUserName(pass.substring(0, pass.indexOf(",")));
								
								pass = pass.substring(pass.indexOf(",")+1);
								
								uib.setAccessTime(pass.substring(0,pass.indexOf(",")));
								
								pass = pass.substring(pass.indexOf(",")+1);
								
								uib.setUserLevel(pass.equals("M")? true:false);
					
								
						break;
					}
					}
			}
		}
		 catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	// 로그인기록 남기기
	public void setLogInInfo(int fileIndex, UserInfoBean uib) {
		file = new File(filePath[fileIndex]);
		try {
			fw = new FileWriter(file,true);
			bw = new BufferedWriter(fw);
			String record;



		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}


}

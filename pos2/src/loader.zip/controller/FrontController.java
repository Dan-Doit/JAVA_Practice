package controller;

import java.util.Scanner;

public class FrontController {
	Scanner sc;

	public FrontController() {
		sc = new Scanner(System.in);
		this.controlTower(this.makeTitle());
		sc.close();
	}

	// Job Control
	private void controlTower(String title) {		// Request : controlTower --> Server
		String [] TT;
		BackController bc = new BackController();
		while (true) {	                   	        //1. logIn  : 성공 --> 2.    실패 --> 1.
			
			TT=bc.logIn(logIn(title));
			if (TT != null) {   //BackController 방만 만들어 놔도 몇번째 방이 null인지 모르기 때문에 null이 아닌걸로 인식됨.
				this.selectService(title,TT);		//2. selectService
			}
		}		
		//        --> Response : controlTower
	}

	// LogIn Job Contol
	private String[] logIn(String title) {
		String[] userInfo = new String[3];
		userInfo[0] = "A1";

		this.display(title);
		this.display(" [ Log In ]\n\n"); 
		this.display(" [ Employee Code ] : ");
		userInfo[1] = sc.next();
		this.display(" [ Access Code ]   : ");
		userInfo[2] = sc.next();

		return userInfo;
	}

	// Services Selection Job Control
	private void selectService(String title, String[] result) {
		this.display(title);
		for (int i = 0; i < result.length; i++) {
			display("["+result[i]+"]"+"  ");
		}

		this.display("\n\n [서비스 선택]\n\n");
		this.display("   1. 상품판매             2. 상품반품\n");

		if(result[2].equals("Manager")) {
			this.display("   3. 직원관리             4. 영업관리\n");
		}

		this.display(" ________________________________ Select :");
		sc.next();
	}

	// User Registration


	// Sales
	private void sales() {

		this.display("상품판매");


	}

	// 타이틀 작성
	private String makeTitle() {
		StringBuffer sb = new StringBuffer();

		sb.append("\n\n");
		sb.append("*************************************************\n");
		sb.append("\n");
		sb.append("         Point Of Sales System v1.0\n");
		sb.append("\n");   
		sb.append("                      Designed by HoonZzang\n");
		sb.append("\n");
		sb.append("*************************************************\n");


		return sb.toString();
	}

	// 화면 출력
	private void display(String text) {
		System.out.print(text);
	}
}

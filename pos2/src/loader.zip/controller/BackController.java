package controller;

import data.UserInfoBean;
import services.Access;

public class BackController {
	
	public BackController() {
		
	}
	
	public String[] logIn(String[] userInfo) {		
		String[] result = null;
		UserInfoBean uib = new UserInfoBean();
		uib.setRequestValue(userInfo[0]);   // Client로 부터 전달 받은 userInfo의 값을 UserInfoBean으로 복사
		uib.setEmployeeCode(userInfo[1]);
		uib.setAccessCode(userInfo[2]);
		
		Access ac = new Access();
		ac.entrance(uib);
		
		if (uib.getUserName()!=null) {
			
		
		result = new String[4];
		result[0] = uib.getEmployeeCode();
		result[1] = uib.getUserName();
		result[2] = uib.isUserLevel()? "Manager":"Mate";
		result[3] = uib.getAccessTime();
		
		}
		return result;
		// Job을 처리하기 위해 Access클래스 생성 후 제어하기위한 
		// 참조변수를 스택에 생성

	
		// Access클래스의 Job을 제어하기 위한 entrance메서드 호출
		
		
		// Access 클래스에서 저장된 데이터를 
		// 클라이언트로 보내기 위해 배열변수 저장
		
						

	}
	
	
}
